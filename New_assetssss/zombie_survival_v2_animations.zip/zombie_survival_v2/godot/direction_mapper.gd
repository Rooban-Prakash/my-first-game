extends Node
## Maps an 8-directional movement/aim vector to one of the 4 sprite
## directions you actually have art for (down, left, right, up).
##
## Why: the uploaded pack only has unique pixel art for 4 cardinal
## directions. Rotating those frames for diagonals breaks the pixel
## grid and looks blurry/wrong. Snapping to the nearest cardinal is
## the standard approach used by most top-down pixel games (e.g. the
## player visually faces "down" for both down-left and down-right
## movement). It reads fine in motion and keeps every frame crisp.

## Call this every frame with the player's movement or aim vector.
## Returns one of: "down", "up", "left", "right"
func get_sprite_direction(input_vector: Vector2) -> String:
	if input_vector.length() < 0.1:
		return "down" # fallback / idle default, adjust to last-known if you prefer

	var angle = rad_to_deg(input_vector.angle())
	# angle: 0 = right, 90 = down, -90 = up, 180/-180 = left (Godot Y-down convention)

	if angle > -45 and angle <= 45:
		return "right"
	elif angle > 45 and angle <= 135:
		return "down"
	elif angle > 135 or angle <= -135:
		return "left"
	else:
		return "up"

## Example usage in a player script:
##
## var move_vec = Input.get_vector("move_left","move_right","move_up","move_down")
## var sprite_dir = DirectionMapper.get_sprite_direction(move_vec)
## $AnimatedSprite2D.play("walk_" + sprite_dir)
##
## For 8-way AIM (e.g. twin-stick shooting) use the aim vector instead
## of movement — the body can walk one direction while the gun/bat
## visually snaps to the nearest of the 4 shoot/melee animations
## toward the aim vector, which reads correctly for shoot+move too.
