# Godot TileMap setup — once you have real art

## 1. Import the tileset sheet
- Slice `PROMPT 2` output into a `TileSet` resource in Godot 4.
- Use **32x32** if you want more granular terrain blending; **64x64**
  matches the rest of this project's assets (player/zombie sprites are
  already 112x112 but designed around a 64px world grid).

## 2. Layer structure (bottom to top)
Use separate `TileMapLayer` nodes (Godot 4.3+) or one `TileMap` with
multiple layers — stack in this order so higher layers draw on top:

1. **Terrain** — grass, dirt, mud, gravel, stone, forest floor, wet ground
2. **Water** — river, river edge, shallow water, rapids (set collision
   here so the player can't walk into deep water without a bridge)
3. **Roads** — straight/corner/junction/damaged variants, laid over Terrain
4. **Structures** — house/warehouse/shed wall + floor pieces (enable
   collision on wall tiles, not floor tiles)
5. **Nature** — trees, bushes, fallen logs, rocks (collision on trunks
   only, not the full canopy sprite, so movement doesn't feel blocked)
6. **Props** — crates, barrels, tents, campfire, poles (small collision
   shapes matching visual footprint)
7. **Vehicles** — abandoned cars/trucks (collision matching body shape;
   these make good ambush/cover points for zombies)
8. **Barriers** — fences, barricades (collision on, these define
   chokepoints from the blueprint)

## 3. Terrain Sets for seamless blending
In the TileSet editor, define a **Terrain Set** for the Terrain layer
so grass/dirt/mud/gravel auto-blend at edges instead of hard-cutting.
Do the same for Roads (so straight/corner/junction pieces auto-connect)
and Water (so river edges blend into the bank terrain).

## 4. Matching the blueprint
`world_regions.gd` (included) defines rough tile-space bounding boxes
for each of the 10 regions from `world_blueprint.png`, plus a
`zombie_density` value per region you can feed into your spawner —
denser in Industrial/Forest, lighter in Town/Farm, matching how the
brief described each area's danger level.

## 5. Chokepoints from the blueprint
The blueprint marks two chokepoints explicitly:
- **Highway/river crossing** at the damaged truss bridge (north)
- **Rocky region pass** (east edge)

Give these tiles a narrower walkable width than the surrounding area
and consider scripted zombie horde triggers there — they're natural
ambush points by construction, not just decoration.
