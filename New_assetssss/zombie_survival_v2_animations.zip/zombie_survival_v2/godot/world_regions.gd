extends Node
## World region definitions matching world_blueprint.png.
## Coordinates are in TILE units (not pixels) — divide blueprint pixel
## coordinates by your chosen tile size (32 or 64) when you finalize
## the real map, or just re-eyeball placement once real art exists.
## This is a starting scaffold, not a final coordinate authority.

class Region:
	var name: String
	var rect: Rect2i          # in tile coordinates
	var kind: String          # "town" | "industrial" | "forest" | "farm" | "rocky" | "hidden"
	var zombie_density: float # 0.0 - 1.0, tune per region for pacing
	var is_hidden: bool

	func _init(n, r, k, density, hidden=false):
		name = n
		rect = r
		kind = k
		zombie_density = density
		is_hidden = hidden

var regions: Array[Region] = []

func _ready():
	# Rough tile-space placement derived from the 1800x1200 blueprint
	# at a 64px reference scale (blueprint_px / 64 ≈ tile coord).
	# Re-tune these once you place real art in the TileMap editor.
	regions.append(Region.new("Rural Town",        Rect2i(6,  9,  5, 4),  "town",       0.35))
	regions.append(Region.new("Gas Station",       Rect2i(13, 10, 3, 2),  "town",       0.30))
	regions.append(Region.new("Industrial",        Rect2i(20, 6,  5, 4),  "industrial", 0.45))
	regions.append(Region.new("Forest Camp",       Rect2i(4,  12, 3, 3),  "hidden",     0.20, true))
	regions.append(Region.new("Farm",              Rect2i(16, 14, 4, 3),  "farm",       0.25))
	regions.append(Region.new("Rocky Elevated",    Rect2i(24, 11, 4, 5),  "rocky",      0.40))
	regions.append(Region.new("Dense Forest",      Rect2i(0,  0,  28, 19),"forest",     0.55))
	regions.append(Region.new("Hidden Cabin",      Rect2i(3,  7,  1, 1),  "hidden",     0.15, true))
	regions.append(Region.new("Loot Camp",         Rect2i(23, 15, 1, 1),  "hidden",     0.15, true))

## Returns the highest-priority (smallest / most specific) region
## containing a given tile position — so a Gas Station tile inside the
## broader forest bounding box still resolves to "Gas Station".
func get_region_at(tile_pos: Vector2i) -> Region:
	var best: Region = null
	for r in regions:
		if r.rect.has_point(tile_pos):
			if best == null or (r.rect.size.x * r.rect.size.y) < (best.rect.size.x * best.rect.size.y):
				best = r
	return best

## Convenience for your zombie spawner: pick a spawn-weight for a tile.
func spawn_density_at(tile_pos: Vector2i) -> float:
	var r = get_region_at(tile_pos)
	return r.zombie_density if r else 0.5
