# Image-generation prompts

Use with ChatGPT's image tool, Midjourney, or Leonardo.Ai. If the first
full-map attempt looks muddy or loses detail, generate it in 2x2 or 3x3
quadrants (append "top-left quadrant of the map, showing X and Y regions
only" etc.) with the same prompt/seed, then stitch in an image editor.
Large, densely-detailed single-shot maps are the hardest case for every
current image model — splitting the work gets a much cleaner result.

---

## PROMPT 1 — Full world map

```
Top-down 2D game environment concept art, aerial view directly overhead,
post-apocalyptic Pacific Northwest wilderness, painted semi-realistic
game art style, gritty atmosphere, natural earthy color palette (moss
green, rust orange, weathered gray, dirt brown), cinematic overcast
lighting with soft shadows, strong depth and visual hierarchy, highly
detailed.

A large interconnected survival-game world: dense pine and fir forest
covering most of the terrain, narrow winding dirt trails, fallen trees,
loose rocks, small clearings. A small abandoned rural town with cracked
roads, overgrown yards, broken fences, rusted abandoned cars, collapsed
sheds. One cracked two-lane highway running diagonally through the
world with smaller branching roads, wrecked vehicles, faded road
barriers. An abandoned gas station near the highway with a collapsed
canopy and old fuel pumps. An industrial warehouse yard with shipping
containers, chain-link fencing, scrap piles, a loading dock. A small
abandoned survivor camp tucked into the forest with tents, a dead
campfire, and a wooden watchtower. A natural river cutting through the
map with rocky banks, a damaged steel truss bridge, and a smaller
wooden footbridge upstream. A farm on the outskirts with a weathered
barn, fields gone to seed, and rusted farm equipment. A rocky elevated
region with small cliffs and a narrow traversal path. A hidden forest
clearing with a single abandoned cabin, reachable only by a narrow
trail off the main roads.

Vegetation and rust reclaim every structure — moss on rooftops, vines
through broken windows, grass growing through cracked asphalt, fallen
utility poles, scattered debris and trash. Roads connect all regions
organically, following natural terrain rather than a symmetrical grid.

No characters, no zombies, no creatures, no UI, no HUD, no text, no
labels, no numbers, no minimap, no map legend, no watermark.
```

---

## PROMPT 2 — Tileset / asset sheet

```
Clean top-down 2D game asset reference sheet on a dark neutral
background, organized into clearly separated category rows with visual
grouping (no text labels needed, just spatial separation between
groups):

Row 1 — TERRAIN: grass, dark grass, dirt, mud, gravel, bare stone,
loose rocks, forest floor litter, wet/damp ground — each as a seamless
square tile.

Row 2 — ROADS: straight horizontal road, straight vertical road, road
corner, T-junction, four-way intersection, cracked/damaged road
section, dirt-to-asphalt transition tile, wooden bridge deck tile —
consistent cracked-asphalt texture with faded yellow lane lines.

Row 3 — WATER: river tile, river edge tile (grass-to-water
transition), shallow water, rapids, small waterfall, bridge-over-water
transition tile.

Row 4 — NATURE: tall pine tree, fir tree, small sapling, bush cluster,
tall grass cluster, fallen log, rock formation, cliff-edge tile —
top-down game-asset framing, consistent scale relative to the tiles
above.

Row 5 — STRUCTURES: house wall segment, house floor tile, roof tile
piece, warehouse wall panel, shed wall piece, wooden fence segment,
chain-link fence segment, gate piece.

Row 6 — PROPS: wooden crate, metal barrel, stacked tires, small debris
pile, street light, tipped-over trash bin, wooden pallet, canvas tent,
unlit campfire ring, fallen utility pole with wires.

Row 7 — VEHICLES: abandoned rusted sedan (top-down), pickup truck,
box/delivery truck, motorcycle — all wrecked or weathered, all in the
same top-down orientation.

Row 8 — BARRIERS: wooden plank fence, chain-link fence panel, concrete
traffic barrier, striped road barricade.

Same painted semi-realistic post-apocalyptic art style as a matching
world map: muted earthy tones, moss and rust weathering, consistent
top-down camera angle, consistent light direction across every tile, no
drop shadows crossing between separate tiles, no overlap between
assets, uniform square grid spacing.

No characters, no zombies, no weapons, no UI, no text, no numbers, no
labels, no watermark, no editor interface, no grid lines drawn on top.
```

---

## Tips if a region comes out weak on a full-map attempt

Generate a small follow-up image using just that region's paragraph
from Prompt 1 plus "close-up, top-down 2D game environment concept art,
same style as the wider map" — then composite it into the weak spot in
the full map at matching scale/rotation.
